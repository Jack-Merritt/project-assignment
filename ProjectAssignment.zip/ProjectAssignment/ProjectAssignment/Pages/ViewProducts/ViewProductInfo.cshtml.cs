using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DatabaseConnection.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectAssignment.Pages.DatabaseConnection;
using ProjectAssignment.Models;

namespace DatabaseConnection.Pages.Students
{
    public class ViewDataModel : PageModel
    {
        [BindProperty]
        public List<Product> ProductRec { get; set; }
        public IActionResult OnGet()
        {
            DatabaseConnect dbstring = new DatabaseConnect();
            string DbConnection = dbstring.DatabaseString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM Product WHERE ProductId = @PId"; // try order by Name

                SqlDataReader reader = command.ExecuteReader();

                ProductRec = new List<Product>();
                // Call Read before accessing data.
                while (reader.Read())//keep reading while there is a record
                {
                    Product rec = new Product(); //a local var to hold a record temporarily
                    rec.Id = reader.GetInt32(0);
                    rec.ProductName = reader.GetString(1); //make sure the data type is matched
                    rec.ProductType = reader.GetString(2);
                    rec.ProductPrice = reader.GetInt32(3);
                    rec.ProductImageFile = reader.GetString(4);
                    ProductRec.Add(rec); //the temporary var of rec which consists of a record is added to the the list
                }

                // Call Close when done reading.
                reader.Close();
            }
            return Page();//return to the page after the result is obtained
        }
    }
}