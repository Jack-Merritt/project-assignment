using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Login_Session.Models;
using Login_Session.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectAssignment.Models;
using ProjectAssignment.Pages.DatabaseConnection;

namespace Login_Session.Pages.Login
{
     public class LoginModel : PageModel
     {
          [BindProperty]
          public User User { get; set; }
          public string Message { get; set; }

          public string SessionID;


          public void OnGet()
          {
          }

          public IActionResult OnPost()
          {
               if (!ModelState.IsValid)
               {
                  return Page();
               }


               DatabaseConnect dbstring = new DatabaseConnect(); // creating an object from the class
               string DbConnection = dbstring.DatabaseString(); // calling the method from the class
               Console.WriteLine(DbConnection);
               SqlConnection conn = new SqlConnection(DbConnection);
               conn.Open();

               Console.WriteLine(User.UserEmail);
               Console.WriteLine(User.UserPassword);


               using (SqlCommand command = new SqlCommand())
               {
                    command.Connection = conn;
                    command.CommandText = @"SELECT userEmail, userPassword FROM User WHERE UserEmail = @UEmail AND UPassword = @Pwd";

                    command.Parameters.AddWithValue("@UName", User.UserEmail);
                    command.Parameters.AddWithValue("@Pwd", User.UserPassword);

                    var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                         User.UserEmail = reader.GetString(0);
                         User.UserPassword = reader.GetString(1);
                    }


               }

               if (!string.IsNullOrEmpty(User.UserEmail))
               {
                    SessionID = HttpContext.Session.Id;
                    HttpContext.Session.SetString("sessionID", SessionID);
                    HttpContext.Session.SetString("Email", User.UserEmail);
                    HttpContext.Session.SetString("Password", User.UserPassword);
                   }
               else
               {
                    Message = "Invalid Username and Password!";
                    return Page();
               }



          }


         }
}
