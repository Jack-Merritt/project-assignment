using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Login_Session.Models;
using Login_Session.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectAssignment.Models;
using ProjectAssignment.Pages.DatabaseConnection;

namespace ProjectAssignment.Pages.UserPages
{
    public class UserRegistrationModel : PageModel
    {
        [BindProperty]
        public User User { get; set; }
        public string Message { get; set; }

        public string SessionID;

        public List<String> Sex = new List<String> { "Male", "Female" };

        public void OnGet()
        {
        }
    }
    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        DatabaseConnect dbstring = new DatabaseConnect(); // creating an object from the class
        string DbConnection = dbstring.DatabaseString(); // calling the method from the class
        Console.WriteLine(DbConnection);
        SqlConnection conn = new SqlConnection(DbConnection);
        conn.Open();
        try
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO User (UserFirstName, UserSurname, UserSex, UserEmail, UserAddress, UserPhoneNumber, UserPassword) VALUES(@UserFirstName, @UserSurname, @UserSex, @UEmail, @UserAddress, @UserPhoneNumber, @Pwd)";
            cmd.Parameters.AddWithValue("@UserFirstName", User.UserFirstName);
            cmd.Parameters.AddWithValue("@UserSurname", User.UserSurname);
            cmd.Parameters.AddWithValue("@UserSex", User.UserSex);
            cmd.Parameters.AddWithValue("@UserEmail", User.UserEmail);
            cmd.Parameters.AddWithValue("@UserAddress", User.UserAddress);
            cmd.Parameters.AddWithValue("@UserPhoneNumber", User.UserPhoneNumber);
            cmd.Parameters.AddWithValue("@UserPassword", User.UserPassword);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)

        {
            Message = "there was an error adding new user, please check you have added the details correctly...";
            return Page();
        }
        Message= "User Added";
        
    }
}
