using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Login_Session.Models;
using Login_Session.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectAssignment.Models;
using ProjectAssignment.Pages.DatabaseConnection;

namespace ProjectAssignment.Pages.AdminLogin
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public Admin admin { get; set; }
        public string Message { get; set; }

        public string SessionID;
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }


            DatabaseConnect dbstring = new DatabaseConnect(); // creating an object from the class
            string DbConnection = dbstring.DatabaseString(); // calling the method from the class
            Console.WriteLine(DbConnection);
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Admin.StaffId);
            Console.WriteLine(Admin.AdminPassword);


            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT StaffId, adminPassword FROM Admin WHERE StaffId = @StaffId AND APassword = @Pwd";

                command.Parameters.AddWithValue("@AName", Admin.StaffId);
                command.Parameters.AddWithValue("@Pwd", Admin.AdminPassword);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Admin.StaffId = reader.GetString(0);
                    Admin.AdminPassword = reader.GetString(1);
                }


            }

            if (!string.IsNullOrEmpty(Admin.StaffId))
            {
                SessionID = HttpContext.Session.Id;
                HttpContext.Session.SetString("sessionID", SessionID);
                HttpContext.Session.SetString("staffId", Admin.StaffId);
                HttpContext.Session.SetString("Password", Admin.AdminPassword);
            }
            else
            {
                Message = "Invalid ID and Password!";
                return Page();
            }
        }
    }
}

