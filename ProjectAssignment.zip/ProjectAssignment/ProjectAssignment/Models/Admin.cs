﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAssignment.Models
{
    public class Admin
    {
        public int Id { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string AdminFirstName { get; set; }
        [Required]
        [Display(Name = "Surame")]
        public string AdminSurname { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string AdminEmail { get; set; } //We will have year 1,2,3,4 : using checkboxes - True of flase
        [Required]
        [Display(Name = "Password")]
        public string AdminPassword { get; set; }
        [Required]
        [Display(Name = "Address")]
        public string AdminAddress { get; set; }
        [Required]
        [Display(Name = "Phone Number")]
        public string AdminPhoneNumber { get; set; }
        [Required]
        [Display(Name = "Department Id")]
        public int DepartmentId { get; set; }
        [Required]
        [display(name = "StaffId")]
        public int StaffID { get; set; }

    }
}
