﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAssignment.Models
{
    public class User
    {
        public int Id { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string UserFirstName { get; set; }
        [Required]
        [Display(Name = "Surame")]
        public string UserSurname { get; set; }
        [Required]
        [Display(Name = "Sex")]
        public string UserSex { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string UserEmail { get; set; } //We will have year 1,2,3,4 : using checkboxes - True of flase
        [Required]
        [Display(Name = "Password")]
        public string UserPassword { get; set; }
        [Required]
        [Display(Name = "Address")]
        public string UserAddress { get; set; }
        [Required]
        [Display(Name = "Phone Number")]
        public string UserPhoneNumber { get; set; }



    }
}
